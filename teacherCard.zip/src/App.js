import React from "react";
import TeacherCard from "./TeacherCard";

function App() {
  return (
    <div>
      <h1>Teacher Information</h1>

      <TeacherCard
        name="Dr. Usama"
        subject="Computer Science"
        experience="10 Years"
        institute="FAST University"
      />

      <TeacherCard
        name="Sir Rizwan"
        subject="Computer Science"
        experience="6 Years"
        institute="Fast University"
      />

    </div>
  );
}

export default App;