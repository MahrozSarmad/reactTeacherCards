import React from "react";

function TeacherCard(props) {
  return (
    <div style={{
      border: "1px solid black",
      padding: "15px",
      width: "250px",
      borderRadius: "10px",
      margin: "20px"
    }}>
      <h2>{props.name}</h2>
      <p><b>Subject:</b> {props.subject}</p>
      <p><b>Experience:</b> {props.experience}</p>
      <p><b>Institute:</b> {props.institute}</p>
    </div>
  );
}

export default TeacherCard;